# Mixture_Descriptors
This is a project which takes input from two .csv files, first one containing individual descriptors of each components and the second one containing the concentrations values of of each components for each mixtures.
The main function gets threee arguments  1- descriptors file path 2- concentrations file path and 3- output directory (to store the 12 .csv output files)
This code calculates 12 different mixture descriptors and return 12 .csv file for each. 
install the package using conda install  Mixture-Descriptors  or pip install Mixture-Descriptors
